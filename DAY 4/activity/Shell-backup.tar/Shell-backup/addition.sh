echo "addition of numbers"
echo "enter first number"
read a
echo "enter the second number"
read b
echo "sum of 2 numbers is $((c=a+b))"

