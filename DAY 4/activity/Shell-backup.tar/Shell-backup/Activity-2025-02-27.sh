touch Test_File

chmod 540 Test_File

ls -l Test_File

gedit Test_File &
disown

firefox https://github.com &
disown
