#!/bin/bash

# Opening Firefox
firefox https://google.com &
disown

# Opening File Manager
nautilus &
disown

# Opening Document Viewer
evince &
disown

# Opening Editor - gedit
gedit My_Second_Script.sh &
disown 
